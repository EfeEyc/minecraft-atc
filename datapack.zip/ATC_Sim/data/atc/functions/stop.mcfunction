# Remove ALL movement tags from the closest plane (or all planes if you change limit)
tag @e[type=immersive_aircraft:biplane,sort=nearest,limit=1] remove taxiing
tag @e[type=immersive_aircraft:biplane,sort=nearest,limit=1] remove flying

# Reset the timer so it doesn't insta-climb next time
scoreboard players set @e[type=immersive_aircraft:biplane,sort=nearest,limit=1] flight_timer 0

tellraw @a {"text":"[ATC] Aircraft Full Stop.","color":"red"}