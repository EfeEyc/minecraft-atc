# Initialize speed if not set (default to 2: Normal)
execute unless score @s speed matches -2147483648..2147483647 run scoreboard players set @s speed 2

# 1. IDENTIFY SELF & BROADCAST ID
tag @s add active_processing
scoreboard players operation #SEARCH_ID wp_id = @s current_target

# 2. FIND TARGET
execute as @e[type=armor_stand] if score @s wp_id = #SEARCH_ID wp_id run tag @s add lock_on

# 4. PHYSICS
data merge entity @s {NoGravity:1b}

# 5. THE ONE-LINER (Move & Rotate Together based on speed scoreboard)
# Speed 1: Slow (0.1 blocks/tick)
execute if score @s speed matches 1 if entity @e[tag=lock_on] at @s run tp @s ^ ^ ^0.1 facing entity @e[tag=lock_on,limit=1] eyes
# Speed 2: Normal (0.2 blocks/tick)
execute if score @s speed matches 2 if entity @e[tag=lock_on] at @s run tp @s ^ ^ ^0.2 facing entity @e[tag=lock_on,limit=1] eyes
# Speed 3: Fast (0.3 blocks/tick)
execute if score @s speed matches 3 if entity @e[tag=lock_on] at @s run tp @s ^ ^ ^0.3 facing entity @e[tag=lock_on,limit=1] eyes
# Speed 4: Turbo (0.4 blocks/tick)
execute if score @s speed matches 4 if entity @e[tag=lock_on] at @s run tp @s ^ ^ ^0.4 facing entity @e[tag=lock_on,limit=1] eyes

# 6. ARRIVAL CHECK
execute at @s if entity @e[tag=lock_on,distance=..6] run function atc:fetch_next

# 7. CLEANUP
tag @e[tag=lock_on] remove lock_on
tag @s remove active_processing
