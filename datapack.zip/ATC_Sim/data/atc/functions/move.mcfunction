# Initialize speed if not set (default to 2: Normal)
execute unless score @s speed matches -2147483648..2147483647 run scoreboard players set @s speed 2

# 1. BROADCAST ID
tag @s add active_processing
scoreboard players operation #SEARCH_ID wp_id = @s current_target

# 2. FIND TARGET
execute as @e[type=armor_stand] if score @s wp_id = #SEARCH_ID wp_id run tag @s add lock_on

# 3. SAFETY CHECK
tag @s remove safe_to_move
execute if entity @e[tag=lock_on] run tag @s add safe_to_move

# 4. ROTATE & FLATTEN
execute if entity @e[tag=safe_to_move] as @s at @s run tp @s ~ ~ ~ facing entity @e[tag=lock_on,limit=1] feet
execute if entity @e[tag=safe_to_move] as @s at @s run tp @s ~ ~ ~ ~ 0

# 5. MOVE (Taxiing speed based on scoreboard)
# Speed 1: Slow (0.05 blocks/tick)
execute if score @s speed matches 1 if entity @e[tag=safe_to_move] as @s at @s run tp @s ^ ^ ^0.05
# Speed 2: Normal (0.1 blocks/tick)
execute if score @s speed matches 2 if entity @e[tag=safe_to_move] as @s at @s run tp @s ^ ^ ^0.1
# Speed 3: Fast (0.15 blocks/tick)
execute if score @s speed matches 3 if entity @e[tag=safe_to_move] as @s at @s run tp @s ^ ^ ^0.15
# Speed 4: Turbo (0.2 blocks/tick)
execute if score @s speed matches 4 if entity @e[tag=safe_to_move] as @s at @s run tp @s ^ ^ ^0.2

execute if entity @e[tag=safe_to_move] as @s at @s run tp @s ~ -60 ~

# 6. ARRIVAL CHECK (Distance 2)
execute if entity @e[tag=safe_to_move] at @s if entity @e[tag=lock_on,distance=..2] run function atc:fetch_next

# 7. CLEANUP
tag @e[tag=lock_on] remove lock_on
tag @s remove active_processing
tag @s remove safe_to_move
