say hello
