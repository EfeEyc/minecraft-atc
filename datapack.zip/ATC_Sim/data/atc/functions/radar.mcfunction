execute as @e[tag=tracked] store result score @s pos_z run data get entity @s Pos[2] 1
execute as @e[tag=tracked] store result score @s rot_y run data get entity @s Rotation[0] 1
execute as @e[tag=tracked] store result score @s pos_x run data get entity @s Pos[0] 1
execute as @e[tag=tracked] store result score @s pos_y run data get entity @s Pos[1] 1
