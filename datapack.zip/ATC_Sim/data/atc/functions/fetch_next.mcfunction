# 2. POP QUEUE (Remove the current target from the plane's own memory)
# We store the route in 'ForgeData.Route'
data remove entity @s ForgeData.Route[0]

# 3. CHECK IF ROUTE IS EMPTY
tag @s remove route_active
execute if data entity @s ForgeData.Route[0] run tag @s add route_active

# 4. IF ROUTE FINISHED (List is empty)
execute unless entity @e[tag=route_active] run tag @s remove taxiing
execute unless entity @e[tag=route_active] run tag @s remove flying

# 5. IF ROUTE ACTIVE (Get next number)
# We read the NEW first number in the list directly from the entity
execute if entity @e[tag=route_active] store result score @s current_target run data get entity @s ForgeData.Route[0]

# Cleanup
tag @s remove route_active
