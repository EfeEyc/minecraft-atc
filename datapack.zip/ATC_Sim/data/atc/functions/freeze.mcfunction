# 1. LOCK TAXIING PLANES
# These are on the ground, so ~ ~ ~ is fine.
execute as @e[tag=taxiing] run data merge entity @s {Motion:[0.0d,0.0d,0.0d]}
execute as @e[tag=taxiing] at @s run tp @s ~ ~ ~ ~ ~

# 2. LOCK FLYING PLANES (Hover Fix)
# We force NoGravity just in case.
execute as @e[tag=flying] run data merge entity @s {NoGravity:1b, Motion:[0.0d,0.0d,0.0d]}
