# 1. Create objectives to store the X/Z coordinates
# We don't need to create 'wp_id' because you already have it!
scoreboard objectives add wp_x dummy
scoreboard objectives add wp_z dummy

# 2. Sync Coordinates (Only for stands that have a wp_id > 0)
execute as @e[type=armor_stand,scores={wp_id=1..}] store result score @s wp_x run data get entity @s Pos[0] 1
execute as @e[type=armor_stand,scores={wp_id=1..}] store result score @s wp_z run data get entity @s Pos[2] 1

# Note: We don't need to copy wp_id anywhere. Python will just read the original 'wp_id' objective.
tellraw @a {"text":"[ATC] Map Scanned. Reload Python to see changes.","color":"green"}
