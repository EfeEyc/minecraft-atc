# --- 1. PAUSE CHECK ---
# If status is 1, FREEZE everyone and DO NOT run the movement commands below.
execute if score #GLOBAL sim_status matches 1 run function atc:freeze

# --- 2. RUN MOVEMENT (Only if NOT paused) ---
# We use 'unless ... matches 1' to guarantee these never run while paused.

# Taxi Logic
execute unless score #GLOBAL sim_status matches 1 as @e[tag=taxiing] run function atc:move

# Flying Logic
execute unless score #GLOBAL sim_status matches 1 as @e[tag=flying] run function atc:fly

# --- 3. RADAR TELEMETRY ---
# Updates the scoreboards so the website can see the planes
function atc:radar
